<?php
print "Pagina de cadastros";
?>
