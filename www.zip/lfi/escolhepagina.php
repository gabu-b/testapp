<?php
$pagina = $_GET['pagina'];
include($pagina);
?>
