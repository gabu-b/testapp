<?php
echo "Escolha a pagina que deseja visitar<br>"; 

echo "<a href=escolhepagina.php?pagina=cadastro.php>Cadastro</a><br>"; 
echo "<a href=escolhepagina.php?pagina=contato.php>Contato</a><br>"; 
