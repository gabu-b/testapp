<?php
echo "Escolha a pagina que deseja visitar<br>"; 

echo "<a href=rfi.php?page=cadastro.php>Cadastro</a><br>"; 
?>
