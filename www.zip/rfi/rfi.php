<?php
include($_GET['page']);
?>
