<?php
include("config.php");
session_start();
$login = $_POST['login'];
$senha = $_POST['senha'];

/* Verifica se existe usuario, o segredo ta aqui quando ele procupa uma 
linha q contenha o login e a senha digitada */
$sql_logar = "SELECT * FROM usuarios WHERE login = '$login' and senha = '$senha'";
//$user_tratado = addslashes($login);
//$pass_tratado = addslashes($senha);

//$sql_logar = "SELECT * FROM usuarios WHERE login = '$user_tratado' and senha = '$pass_tratado'";


$exe_logar = mysql_query($sql_logar) or die ("Usuario ou senha invalidos");
//$fet_logar = mysql_fetch_assoc($exe_logar);
$num_logar = mysql_num_rows($exe_logar);

while ($row = mysql_fetch_assoc($exe_logar)) {
    $id = $row["ID"];
}
//Verifica se n existe uma linha com o login e a senha digitado
if ($num_logar == 0){
   echo "Login ou senha invalido.";
   //echo "$user_tratado<br>";
   //echo "$pass_tratado<br>";
} 
else{
    $_SESSION['login_user']=$login; 
	$_SESSION['id']=$id; // Initializing Session
    header("location: profile.php?id=$id"); // Redirecting To Other Page
   //echo "Bem Vindo $login";
}
?>