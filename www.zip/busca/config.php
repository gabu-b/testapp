<?php
$host = "SERVER01"; //Servidor do mysql
$user = "sa"; //Usuario do banco de dados
$pass = "123456"; //senha do banco de dados
$banco = "empresa"; //banco de dados

$conn= mssql_connect($host,$user,$pass);
$db= mssql_select_db($banco);
?>
