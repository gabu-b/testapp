<?php
include("config.php");
//$busca_tratado = addslashes($busca);
//$list_usu = "SELECT * FROM usuarios where nome like '%$busca_tratado%'";
$list_usu = "SELECT * FROM usuarios where nome like '%$busca%'";
$result=mssql_query($list_usu) or die ("N�o foi encontrado usuarios cadastrados.");
while ($usu = mssql_fetch_array($result)) {
	$nome = $usu["nome"];
	echo "Nome: $nome\n<br>";
}
?>