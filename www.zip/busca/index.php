<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Document sans titre</title>
<style type="text/css">
<!--
.Style6 {font-size: 13px}
-->
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="busca.php">
  <table width="41%" border="0">
    <tr>
      <td colspan="2"><div align="center"><strong>procurar usu�rio</strong></div></td>
    </tr>
    <tr>
      <td><span class="Style6">Digite o nome a pesquisar:</span></td>
      <td><span class="Style6">
        <label>
        <input name="busca" type="text" id="busca" size="100" />
        </label>
      </span></td>
    </tr>
       <td><span class="Style6">
        <label>
        <input type="submit" name="Submit" value="OK" />
        </label>
      </span></td>
    </tr>
  </table>
</form>
</body>
</html>
