<html>
<body>

<?php
echo "Nome: " . $_GET[nome];
?>

</body>
</html>
