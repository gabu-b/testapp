<?php
include("config.php");

$login = $_POST['login'];
$senha = $_POST['senha'];

/* Verifica se existe usuario, o segredo ta aqui quando ele procupa uma 
linha q contenha o login e a senha digitada */
$sql_logar = "SELECT * FROM usuarios WHERE login = '$login' and senha = '$senha'";
//$user_tratado = addslashes($login);
//$pass_tratado = addslashes($senha);

//$sql_logar = "SELECT * FROM usuarios WHERE login = '$user_tratado' and senha = '$pass_tratado'";


$exe_logar = mysql_query($sql_logar) or die ("Usuario ou senha invalidos");
$fet_logar = mysql_fetch_assoc($exe_logar);
$num_logar = mysql_num_rows($exe_logar);

//Verifica se n existe uma linha com o login e a senha digitado
if ($num_logar == 0){
   echo "Login ou senha invalido.";
   //echo "$user_tratado<br>";
   //echo "$pass_tratado<br>";
} 
else{
   echo "Bem Vindo $login";
}
?>