CREATE DATABASE blind;
USE blind;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;
INSERT INTO `users` (`id`, `name`, `password`) VALUES
(4, 'administrator', 'admin'),
(5, 'usuario1', '123456'),
(6, 'usuario2', '654321');