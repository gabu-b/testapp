<?php
# ���� CONFIGURA��O DE BANCO �����
$host = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'blind';

echo "<title>LAB Blind SQLi</title>";
$db = mysql_connect($host, $dbuser, $dbpass);
mysql_select_db($dbname,$db);
$sql = "SELECT * FROM users WHERE id=".$_GET['id'];
$query = mysql_query($sql);

if(@mysql_num_rows($query)==0){
      die;
}

$result=@mysql_fetch_row($query);

echo "<h2><center><u>Blind SQL Injection</u><br><br>";
echo "user_id: ".$result[0]."<br>";
echo "username: ".$result[1]."<br>";
// echo "Password: ".$result[2]."<br>";
echo "</h2></center>";
die();
?>